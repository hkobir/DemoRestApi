<?php
define('DB_HOST','localhost');
define('DB_USER','id12383866_kobir');
define('DB_PASSWORD','123456');
define('DB_NAME','id12383866_demoapi');

define('USER_CREATED',101);
define('USER_EXISTS',102);
define('USER_FAILURE',103);

define('USER_AUTHENTICATED',201);
define('USER_NOT_FOUND',202);
define('USER_PASSWORD_NOT_MATCHED',203);
?>